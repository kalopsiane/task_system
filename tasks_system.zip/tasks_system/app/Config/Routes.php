<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'TaskController::welcome');
$routes->get('tasks', 'TaskController::tasks');
$routes->get('profile', 'TaskController::profile');
$routes->get('about', 'TaskController::about');
