<?php

namespace App\Controllers;

use App\Models\TaskModel;
use App\Models\UserModel;

class TaskController extends BaseController
{
    public function welcome()
    {
        $taskModel = new TaskModel();

        $data = [
            'title' => 'Welcome',
            'tasks' => $taskModel
                ->where('task_date', date('Y-m-d'))
                ->orderBy('task_date', 'ASC')
                ->findAll()
        ];

        return view('welcome', $data);
    }

    public function tasks()
    {
        $taskModel = new TaskModel();

        $data = [
            'title' => 'Task List',
            'tasks' => $taskModel
                ->orderBy('task_date', 'ASC')
                ->orderBy('id', 'ASC')
                ->findAll()
        ];

        return view('tasks', $data);
    }

    public function profile()
    {
        $userModel = new UserModel();

        $data = [
            'title' => 'Profile',
            'user' => $userModel->first()
        ];

        return view('profile', $data);
    }

    public function about()
    {
        $data = [
            'title' => 'About'
        ];

        return view('about', $data);
    }
}