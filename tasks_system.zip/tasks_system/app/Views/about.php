<!DOCTYPE html>
<html>
<head>
    <title><?= esc($title) ?></title>
</head>
<body>
    <h1>About the System</h1>

    <nav>
        <a href="/">Welcome</a> |
        <a href="/tasks">Task List</a> |
        <a href="/profile">Profile</a> |
        <a href="/about">About</a>
    </nav>

    <p>
        This Tasks for Today Management System was developed by
        <strong>Aneryl Alafriz</strong>.
    </p>

    <p>
        The system was created using CodeIgniter 4, PHP, and MySQL.
    </p>
</body>
</html>